CREATE VIEW v_category_stats AS
SELECT
    COALESCE(category, 'Без категории') AS category,
    COUNT(*) AS total_requests,
    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS successful_requests,
    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_requests,
    SUM(CASE WHEN was_escalated = 1 OR status = 'escalated' THEN 1 ELSE 0 END) AS escalated_requests,
    ROUND(AVG(response_time_ms), 2) AS avg_response_time_ms,
    ROUND(AVG(confidence), 4) AS avg_confidence
FROM requests
GROUP BY category
ORDER BY total_requests DESC;

