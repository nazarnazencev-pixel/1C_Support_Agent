CREATE VIEW v_daily_stats AS
SELECT
    substr(created_at, 1, 10) AS day,
    COUNT(*) AS total_requests,
    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS successful_requests,
    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_requests,
    SUM(CASE WHEN was_escalated = 1 OR status = 'escalated' THEN 1 ELSE 0 END) AS escalated_requests,
    ROUND(AVG(response_time_ms), 2) AS avg_response_time_ms,
    ROUND(AVG(confidence), 4) AS avg_confidence
FROM requests
GROUP BY substr(created_at, 1, 10)
ORDER BY day DESC;

