CREATE VIEW v_dashboard_summary AS
SELECT
    COUNT(*) AS total_requests,
    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS successful_requests,
    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_requests,
    SUM(CASE WHEN was_escalated = 1 OR status = 'escalated' THEN 1 ELSE 0 END) AS escalated_requests,
    ROUND(AVG(CASE WHEN response_time_ms IS NOT NULL THEN response_time_ms END), 2) AS avg_response_time_ms,
    ROUND(AVG(CASE WHEN confidence IS NOT NULL THEN confidence END), 4) AS avg_confidence,
    ROUND(100.0 * SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 2) AS success_rate_percent
FROM requests;

